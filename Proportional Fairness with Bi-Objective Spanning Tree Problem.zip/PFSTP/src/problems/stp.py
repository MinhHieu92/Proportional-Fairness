import _pickle

from .base import Problem


class STProblem(Problem):
    def __init__(self, path: str) -> None:
        super().__init__(path)
        self.type = "stp"

    def read_file(self, path: str):
        """Read a networkx graph from a pickle file. """
        with open(path, "rb") as f:
            self.graph = _pickle.load(f)

        self.graph.graph["name"] = path.split("/")[-1].split(".")[0]
