from collections import defaultdict
from time import time

import numpy as np

from constant import TOLERANCE
from .base import Solver, cplex, CALLBACK_NAME
from problems.stp import STProblem
from .callbacks.base import BaseLazyCallback
from .callbacks.separators.separator_name import SEPARATOR_NAME


class STPSolver(Solver):
    def __init__(self, problem: STProblem, cut_type: str, **kwargs) -> None:
        super().__init__(problem, **kwargs)
        self.create_mip_formulation(kwargs["vtype"])
        # print(self.edge2idx)
        self.separator = SEPARATOR_NAME[cut_type](problem, self.edge2idx)

        lazy_constraint = self.register_callback(BaseLazyCallback)
        lazy_constraint.set_attribute(self.separator)

    def create_mip_formulation(self, vtype: str = "B"):
        # create edge variables
        for edge in self.graph.edges:
            var_name = "x.{}.{}".format(*edge)
            self.edge2idx[edge] = self.variables.add(
                lb=[0.0],
                ub=[1.0],
                types=[vtype],
                names=[var_name],
            )[0]

        # create constraints: sum_{e \in E} x_e = n - 1 where n is the number of nodes
        sum_constraints = cplex.SparsePair(ind=list(self.edge2idx.values()), val=[1] * len(self.edge2idx))
        self.linear_constraints.add(
            lin_expr=[sum_constraints],
            senses=["E"],
            rhs=[len(self.graph.nodes) - 1],
        )

    def create_objective_function(self):
        # create objective function: max_{e \in E} c_e * x_e
        self.objective.set_sense(self.objective.sense.maximize)
        for edge in self.graph.edges:
            self.objective.set_linear([(self.edge2idx[edge], self.graph.edges[edge]["weight"])])

    def basic_solve(self, *args, **kwargs):
        user_callback = None
        if "user_callback" in kwargs:
            user_callback = self.register_callback(
                CALLBACK_NAME[kwargs["user_callback"]]
            )
            user_callback.set_attribute(self.separator, **kwargs["user_cb_kwargs"])

        self.solve()

        used_weights = []
        used_costs = []
        solution = np.asarray(self.solution.get_values())
        nz_indices = np.intersect1d(np.where(solution > TOLERANCE)[0].tolist(),
                                    np.asarray(list(self.edge2idx.values())))
        idx2edge = {idx: edge for edge, idx in self.edge2idx.items()}

        for idx in nz_indices:
            used_weights.append(self.graph.edges[idx2edge[idx]]["weight"])
            used_costs.append(self.graph.edges[idx2edge[idx]]["cost"])
        return sum(used_weights), min(used_costs)


class MaxminSTPSolver(STPSolver):
    def create_mip_formulation(self):
        super().create_mip_formulation()

        # add constraint to represent the minimal cost of a spanning tree
        edge2cost = {edge: self.graph.edges[edge]["cost"] for edge in self.edge2idx}
        M = max(edge2cost.values())
        self.q_idx = self.variables.add(lb=[0.0], types=["C"], names=["q"], )[0]
        for edge in self.edge2idx:
            self.linear_constraints.add(
                lin_expr=[cplex.SparsePair(ind=[self.q_idx, self.edge2idx[edge]], val=[1, M - edge2cost[edge]])],
                senses=["L"],
                rhs=[M],
            )

    def create_objective_function(self):
        # create objective function: max Q
        self.objective.set_sense(self.objective.sense.maximize)
        self.objective.set_linear([(self.q_idx, 1)])


class FSTPSolver(STPSolver):
    # def __init__(self, problem: STProblem, cut_type: str, **kwargs) -> None:
    #     super().__init__(problem, cut_type, **kwargs)

    def create_mip_formulation(self, vtype: str = "B"):
        super().create_mip_formulation(vtype=vtype)

        # add constraint to represent the total cost of a spanning tree
        self.p_idx = self.variables.add(names=["p"], )[0]

        edge2weight = {edge: self.graph.edges[edge]["weight"] for edge in self.edge2idx}
        self.linear_constraints.add(
            lin_expr=[cplex.SparsePair(ind=list(self.edge2idx.values()) + [self.p_idx],
                                       val=list(edge2weight.values()) + [-1])],
            senses=["E"],
            rhs=[0],
        )

        # add constraint to represent the minimal cost of a spanning tree
        edge2cost = {edge: self.graph.edges[edge]["cost"] for edge in self.edge2idx}
        # print("edge2weight == edge2cost:", edge2weight == edge2cost)
        M = max(edge2cost.values())
        self.q_idx = self.variables.add(lb=[0.0], types=["C"], names=["q"], )[0]
        for edge in self.edge2idx:
            self.linear_constraints.add(
                lin_expr=[cplex.SparsePair(ind=[self.q_idx, self.edge2idx[edge]], val=[1, M - edge2cost[edge]])],
                senses=["L"],
                rhs=[M],
            )

    def create_objective_function(self, alpha: float):
        # create objective function: max P + alpha * Q
        self.objective.set_sense(self.objective.sense.maximize)
        self.objective.set_linear([(self.p_idx, 1), (self.q_idx, alpha)])
        # self.objective.set_linear([(self.p_idx, 1)])


class GSTPSolver(FSTPSolver):
    def __init__(self, problem: STProblem, cut_type: str, **kwargs) -> None:
        super().__init__(problem, cut_type, **kwargs)
        self.t_idx = None
        self.t_cons_idx = None

    def create_objective_function(self, alpha: float):
        if self.t_idx is None:
            self.t_idx = self.variables.add(lb=[0.0], types=["C"], names=["t"], )[0]

        if self.t_cons_idx is not None:
            self.linear_constraints.delete(self.t_cons_idx)

        self.t_cons_idx = self.linear_constraints.add(
            lin_expr=[
                cplex.SparsePair(ind=[self.t_idx, self.p_idx, self.q_idx], val=[1, -1, alpha]),
                cplex.SparsePair(ind=[self.t_idx, self.p_idx, self.q_idx], val=[1, 1, -alpha]),
            ],
            senses=["G", "G"],
            rhs=[0, 0],
        )

        # create objective function: max P + alpha * Q - t
        self.objective.set_sense(self.objective.sense.maximize)
        self.objective.set_linear([(self.p_idx, 1), (self.q_idx, alpha), (self.t_idx, -1)])


class MinMinSTPSolver(STPSolver):
    # def __init__(self, problem: STProblem, cut_type: str, **kwargs) -> None:
    #     super().__init__(problem, cut_type, **kwargs)

    def create_mip_formulation(self, vtype: str = "B"):
        super().create_mip_formulation(vtype=vtype)

        # add constraint to represent the total cost of a spanning tree
        self.p_idx = self.variables.add(names=["p"], )[0]

        edge2weight = {edge: self.graph.edges[edge]["weight"] for edge in self.edge2idx}
        self.linear_constraints.add(
            lin_expr=[cplex.SparsePair(ind=list(self.edge2idx.values()) + [self.p_idx],
                                       val=list(edge2weight.values()) + [-1])],
            senses=["E"],
            rhs=[0],
        )

        # add constraint to represent the minimal cost of a spanning tree
        edge2cost = {edge: self.graph.edges[edge]["cost"] for edge in self.edge2idx}
        # print("edge2weight == edge2cost:", edge2weight == edge2cost)
        M = max(edge2cost.values())
        self.q_idx = self.variables.add(lb=[0.0], types=["C"], names=["q"], )[0]
        for edge in self.edge2idx:
            self.linear_constraints.add(
                lin_expr=[cplex.SparsePair(ind=[self.q_idx, self.edge2idx[edge]], val=[1, - edge2cost[edge]])],
                senses=["G"],
                rhs=[0],
            )

    def create_objective_function(self, alpha: float):
        # create objective function: max P + alpha * Q
        self.objective.set_sense(self.objective.sense.minimize)
        self.objective.set_linear([(self.p_idx, 1), (self.q_idx, alpha)])
        # self.objective.set_linear([(self.p_idx, 1)])

