import sys
from time import time
from typing import *

import networkx as nx
import numpy as np

from constant import TOLERANCE
from .separators.base import Separator
from ..cplex_api import cplex, LazyConstraintCallback, UserCutCallback


class BaseLazyCallback(LazyConstraintCallback):
    def __call__(self):
        # print("Lazy callback called")
        solution = np.asarray(self.get_values())
        nz_indices = np.intersect1d(np.where(solution > TOLERANCE)[0].tolist(),
                                    np.asarray(list(self.separator.var2idx.values())))
        idx2edge = {idx: edge for edge, idx in self.separator.var2idx.items()}

        # for idx in nz_indices:
        #     print(idx, idx2edge[idx], solution[idx])

        support_graph = self.separator.create_support_graph(solution)
        # check connectivity of support graph
        # print("Support graph is connected:", nx.is_connected(support_graph))
        constraints = self.separator.get_lazy_constraints(support_graph)
        for vars, coefs, sense, rhs in constraints:
            self.add(constraint=cplex.SparsePair(vars, coefs), sense=sense, rhs=rhs)

    def set_attribute(self, separator: Separator, *args, **kwargs):
        self.separator = separator


class BaseUserCallback(UserCutCallback):
    def __call__(self, *args: Any, **kwds: Any) -> Any:
        if not self.is_after_cut_loop():
            return

        self.processed_nodes = self.get_num_nodes()
        if self.processed_nodes % self.frequent != 0:
            return

        if self.get_MIP_relative_gap() < self.terminal_gap:
            return

        s = time()
        self.actions[1] += 1
        solution = np.asarray(self.get_values())
        support_graph = self.separator.create_support_graph(solution)
        cuts = self.separator.get_user_cuts(support_graph)

        for vars, coefs, sense, rhs in cuts:
            self.add(cut=cplex.SparsePair(vars, coefs), sense=sense, rhs=rhs)
        self.total_cuts += len(cuts)
        if len(cuts) > 0:
            self.portion_cuts["cuts"] += 1
        else:
            self.portion_cuts["other"] += 1
        msg = "At node {}, add {} user cuts in {:.4f}s, total cuts {}\n".format(
            self.get_num_nodes(), len(cuts), time() - s, self.total_cuts
        )
        if self.logger is not None:
            self.logger.write(msg)
        else:
            print(msg, end="")

    def set_attribute(self, separator: Separator, *args, **kwargs):
        self.separator: Separator = separator
        self.total_cuts = 0
        self.frequent = kwargs["frequent"] if "frequent" in kwargs else 1
        self.terminal_gap = kwargs["terminal_gap"] if "terminal_gap" in kwargs else 0
        self.logger = kwargs["logger"] if "logger" in kwargs else sys.stdout
        self.processed_nodes = 0
        self.actions = {0: 0, 1: 0}
        self.portion_cuts = {"cuts": 0, "other": 0}
