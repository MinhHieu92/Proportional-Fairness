import math
import os
from time import time

import networkx as nx
import numpy as np

from constant import TOLERANCE
from problems.stp import STProblem
from solvers.stp import STPSolver, FSTPSolver, GSTPSolver, MaxminSTPSolver, MinMinSTPSolver
from pf_algorithm import PFAlgorithm
from utils import is_pair_wise_equal


# generate a random complete graph with Euclidean distances by networkx given the number of nodes and a seed
# weights of edges are Euclidean distances
# save it to a file in the folder data/{nb_nodes}/{seed}.pkl (create folder if not exist)
def generate_euclidian_stp_instance(nb_nodes: int, seed: int) -> None:
    G = nx.random_geometric_graph(nb_nodes, 1, seed=seed)
    pos = nx.get_node_attributes(G, 'pos')

    for edge in G.edges:
        G.edges[edge]["weight"] = math.sqrt(
            (pos[edge[0]][0] - pos[edge[1]][0]) ** 2 + (pos[edge[0]][1] - pos[edge[1]][1]) ** 2)

    # create folder if not exist
    if not os.path.exists(f"../data/{nb_nodes}"):
        os.makedirs(f"../data/{nb_nodes}")
    nx.write_gpickle(G, f"../data/{nb_nodes}/E{nb_nodes}_{seed}.pkl")


def generate_random_stp_instance(nb_nodes: int, seed: int) -> None:
    # G = nx.complete_graph(nb_nodes)
    G = nx.gnp_random_graph(nb_nodes, 0.5, seed=seed)
    np.random.seed(seed)

    for edge in G.edges:
        G.edges[edge]["weight"] = np.random.randint(1, 1000)
        G.edges[edge]["cost"] = 100 - int(G.edges[edge]["weight"] / 10)

    if not os.path.exists(f"../data/{nb_nodes}"):
        os.makedirs(f"../data/{nb_nodes}")
    nx.write_gpickle(G, f"../data/{nb_nodes}/GNP{nb_nodes}_{seed}.pkl")


def solve_stp(path: str):
    prob = STProblem(path)
    solver = STPSolver(prob, "subtour")
    solver.create_objective_function()

    solver.write("stp.lp")
    solver.basic_solve()
    print("The optimal value is", solver.solution.get_objective_value())

    solution = np.asarray(solver.solution.get_values())
    nz_indices = np.intersect1d(np.where(solution > TOLERANCE)[0].tolist(),
                                np.asarray(list(solver.edge2idx.values())))
    idx2edge = {idx: edge for edge, idx in solver.edge2idx.items()}

    for idx in nz_indices:
        print(idx2edge[idx], prob.graph.edges[idx2edge[idx]]["weight"])


def solve_fstp(path: str, alpha: float):
    prob = STProblem(path)
    solver = FSTPSolver(prob, "subtour")
    solver.create_objective_function(alpha=alpha)

    solver.write("stp.lp")
    solver.basic_solve()

    solution = np.asarray(solver.solution.get_values())
    nz_indices = np.intersect1d(np.where(solution > TOLERANCE)[0].tolist(),
                                np.asarray(list(solver.edge2idx.values())))
    idx2edge = {idx: edge for edge, idx in solver.edge2idx.items()}

    for idx in nz_indices:
        print(idx2edge[idx], prob.graph.edges[idx2edge[idx]]["weight"])


def solve_gstp(path: str, alpha: float):
    prob = STProblem(path)
    solver = GSTPSolver(prob, "subtour")
    solver.create_objective_function(alpha=alpha)

    solver.write("stp1.lp")
    P, Q = solver.basic_solve()
    print("The objective function is:", solver.solution.get_objective_value())
    print("P:", P)
    print("Q:", Q)

    solver.create_objective_function(alpha=alpha + 1)
    solver.write("stp2.lp")
    P, Q = solver.basic_solve()
    print("The objective function is:", solver.solution.get_objective_value())
    print("P:", P)
    print("Q:", Q)


def solve_multiple_instance():
    for n_nodes in [15, 20, 25, 30, 35, 40]:
        for i in range(1, 50):
            generate_random_stp_instance(n_nodes, i)
            prob = STProblem(f"../data/{n_nodes}/GNP{n_nodes}_{i}.pkl")

            s = time()
            maxmin_solver = MaxminSTPSolver(prob, "subtour", display_log=False)
            maxmin_solver.create_objective_function()
            P_maxmin, Q_maxmin = maxmin_solver.basic_solve()
            t_maxmin = time() - s

            s = time()
            fstp_solver = FSTPSolver(prob, "subtour", display_log=False)
            fstp_solver.create_objective_function(alpha=0)
            P_0, Q_0 = fstp_solver.basic_solve()
            t_0 = time() - s

            s = time()
            pf_solver = PFAlgorithm(prob, display_log=False)
            P_pf, Q_pf = pf_solver.solve()
            t_pf = time() - s

            print("At iteration", i, "the PF solution is", P_pf, Q_pf, "in", t_pf, "seconds")
            with open(f"results_{n_nodes}.csv", "a") as file:
                file.write(f"{prob.graph.graph['name']},{P_maxmin},{Q_maxmin},{t_maxmin},{P_0},{Q_0},{t_0},{P_pf},{Q_pf},{t_pf}\n")


if __name__ == "__main__":
    for i in range(1, 50):
        for n_nodes in [20, 25, 30]:
            # i = 10
            # n_nodes = 20

            prob = STProblem(f"../data/{n_nodes}/GNP{n_nodes}_{i}.pkl")
            solver = MinMinSTPSolver(prob, "subtour", display_log=False, vtype="C")
            solver.create_objective_function(alpha=111)
            solver.write("fstp.lp")
            solver.basic_solve()
            obj_1 = solver.solution.get_objective_value()
            # print("The objective function is:", solver.solution.get_objective_value())

            # s2 = MinMinSTPSolver(prob, "subtour", display_log=False, vtype="C")
            # s2.create_objective_function(alpha=111)
            # s2.basic_solve()
            # obj_2 = s2.solution.get_objective_value()
            #
            # print("At iteration", i, "equal", obj_1 == obj_2)
            solution = np.asarray(solver.solution.get_values())
            nz_indices = np.intersect1d(np.where(solution > TOLERANCE)[0].tolist(),
                                        np.asarray(list(solver.edge2idx.values())))
            idx2edge = {idx: edge for edge, idx in solver.edge2idx.items()}

            for idx in nz_indices:
                print(idx2edge[idx], solution[idx])
