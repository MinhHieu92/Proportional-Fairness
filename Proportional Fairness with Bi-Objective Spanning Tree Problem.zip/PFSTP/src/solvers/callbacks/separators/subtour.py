from typing import *

import networkx as nx
import numpy as np

from solvers.callbacks.separators.base import Separator
from constant import TOLERANCE
from utils import nodes2edge


class SubtourSeparator(Separator):
    def __init__(self, problem, var2idx: Dict[Any, int], **kwargs) -> None:
        super().__init__(problem, var2idx)
        self.cut_type = "subtour"
        self.list_indices = np.asarray(list(self.idx2var.keys()))

    def create_support_graph(self, solution: np.array) -> nx.Graph:
        support_graph = nx.Graph()
        support_graph.add_nodes_from(self.graph.nodes)

        nz_indices = np.intersect1d(np.where(solution > TOLERANCE)[0].tolist(), self.list_indices)

        for idx in nz_indices:
            support_graph.add_edge(*self.idx2var[idx], weight=solution[idx])

        return support_graph

    def get_lazy_constraints(
            self, support_graph: nx.Graph
    ) -> List[Tuple[List[int], List[int], str, int]]:
        tree: nx.Graph = nx.gomory_hu_tree(support_graph, capacity="weight")
        cuts: List[Tuple[List[int], List[int], str, int]] = []

        for edge in tree.edges:
            if 1 - tree.edges[edge]["weight"] > TOLERANCE:
                w = tree.edges[edge]["weight"]
                tree.remove_edge(*edge)
                V1 = nx.node_connected_component(tree, edge[0])
                V2 = nx.node_connected_component(tree, edge[1])
                tree.add_edge(edge[0], edge[1], weight=w)

                vars = []
                for u in V1:
                    for v in V2:
                        if nodes2edge(u, v) in self.var2idx:
                            vars.append(self.var2idx[nodes2edge(u, v)])
                coefs = [1] * len(vars)
                sense = "G"

                if len(vars) > 0:
                    cuts.append((vars, coefs, sense, 1))

        return cuts

    def get_user_cuts(
            self, support_graph: nx.Graph
    ) -> List[Tuple[List[int], List[int], str, int]]:
        tree: nx.Graph = nx.gomory_hu_tree(support_graph, capacity="weight")
        cuts: List[Tuple[List[int], List[int], str, int]] = []

        for edge in tree.edges:
            if 2 - tree.edges[edge]["weight"] > TOLERANCE:
                w = tree.edges[edge]["weight"]
                tree.remove_edge(*edge)
                V1 = nx.node_connected_component(tree, edge[0])
                V2 = nx.node_connected_component(tree, edge[1])
                tree.add_edge(edge[0], edge[1], weight=w)

                vars = []
                for u in V1:
                    for v in V2:
                        vars.append(self.var2idx[nodes2edge(u, v)])
                coefs = [1] * len(vars)
                sense = "G"

                cuts.append((vars, coefs, sense, 2))

        return cuts
