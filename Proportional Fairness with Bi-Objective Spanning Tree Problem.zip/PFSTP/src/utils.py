import re
import typer

from constant import TOLERANCE

app = typer.Typer()


@app.command()
def get_num_nodes_from_path(path: str):
    tmp = path.split("/")
    nums = re.findall(r'\d+', tmp[-1])
    return int(nums[0])


def nodes2edge(u, v):
    return min(u, v), max(u, v)


# function to compare two float tuples t1 = (u,v) and t2 = (x,y)
def is_pair_wise_equal(t1, t2):
    return abs(t1[0] - t2[0]) < TOLERANCE and abs(t1[1] - t2[1]) < TOLERANCE


if __name__ == "__main__":
    app()
