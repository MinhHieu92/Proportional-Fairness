from .subtour import SubtourSeparator

SEPARATOR_NAME = {
    "subtour": SubtourSeparator,
}