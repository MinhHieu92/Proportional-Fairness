from typing import Tuple, Union

from constant import TOLERANCE
from problems.stp import STProblem
from solvers.stp import FSTPSolver, GSTPSolver
from utils import is_pair_wise_equal


class PFAlgorithm:
    def __init__(self, problem: STProblem, **kwargs) -> None:
        self.problem = problem
        self.fstp_solver = FSTPSolver(problem, "subtour", **kwargs)
        self.gstp_solver = GSTPSolver(problem, "subtour", **kwargs)

    def is_pf_sol(self, alpha: float, P: float, Q: float):
        if abs(P - alpha * Q) < TOLERANCE:
            return True

        alpha_ = P / Q
        self.fstp_solver.create_objective_function(alpha=alpha_)
        # self.fstp_solver.write("fstp.lp")
        P_, Q_ = self.fstp_solver.basic_solve()
        # print("P_:", P_, "Q_:", Q_)

        if abs((P + alpha_ * Q) - (P_ + alpha_ * Q_)) < TOLERANCE:
            return True

        return False

    def verify_pf_coef(self, alpha: float) -> Union[Tuple[float, float], Tuple[None, None]]:
        self.fstp_solver.create_objective_function(alpha=alpha)
        P_f, Q_f = self.fstp_solver.basic_solve()

        self.gstp_solver.create_objective_function(alpha=alpha)
        P_g, Q_g = self.gstp_solver.basic_solve()

        g_alpha = P_g + alpha * Q_g - abs(P_f - alpha * Q_f)
        f_alpha = P_f + alpha * Q_f
        if abs(g_alpha - f_alpha) < TOLERANCE:
            return P_g, Q_g

        return None, None

    def search(self, alpha_i, P_i, Q_i, alpha_j, P_j, Q_j) -> Union[Tuple[float, float], None]:
        alpha_k = (P_i - P_j) / (Q_j - Q_i)
        if alpha_i < alpha_k < alpha_j:
            self.fstp_solver.create_objective_function(alpha=alpha_k)
            P_k, Q_k = self.fstp_solver.basic_solve()
            print("(P_k, Q_k) = ({}, {})".format(P_k, Q_k))
            if not is_pair_wise_equal((P_k, Q_k), (P_i, Q_i)) and not is_pair_wise_equal((P_k, Q_k), (P_j, Q_j)):
                if self.is_pf_sol(alpha_k, P_k, Q_k):
                    return P_k, Q_k
                P_, Q_ = self.verify_pf_coef(alpha_k)
                if P_ is not None and Q_ is not None:
                    return P_, Q_
                else:
                    T_k = P_k - alpha_k * Q_k
                    if T_k > 0:
                        return self.search(alpha_k, P_k, Q_k, alpha_j, P_j, Q_j)
                    elif T_k < 0:
                        return self.search(alpha_i, P_i, Q_i, alpha_k, P_k, Q_k)
            else:
                return -1, -1
        else:
            return -1, -1

    def solve(self):
        self.fstp_solver.create_objective_function(alpha=0)
        self.fstp_solver.write("fstp_initial.lp")
        P_0, Q_0 = self.fstp_solver.basic_solve()

        if self.is_pf_sol(0, P_0, Q_0):
            print(f"(P_0, Q_0) = ({P_0}, {Q_0}) is the PF solution")
            return P_0, Q_0

        alpha_sup = P_0 / Q_0 + 1
        self.fstp_solver.create_objective_function(alpha=alpha_sup)
        P_sup, Q_sup = self.fstp_solver.basic_solve()

        if self.is_pf_sol(alpha_sup, P_sup, Q_sup):
            print(f"(P_sup, Q_sup) = ({P_sup}, {Q_sup}) is the PF solution")
            return P_sup, Q_sup

        print("Searching...")
        return self.search(0, P_0, Q_0, alpha_sup, P_sup, Q_sup)
