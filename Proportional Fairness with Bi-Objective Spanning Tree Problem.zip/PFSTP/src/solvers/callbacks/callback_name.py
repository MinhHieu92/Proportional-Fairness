from .base import *


CALLBACK_NAME = {
    "BaseUserCallback": BaseUserCallback,
}
