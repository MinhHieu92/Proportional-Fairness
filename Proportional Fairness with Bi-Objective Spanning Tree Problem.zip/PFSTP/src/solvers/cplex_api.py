import sys
sys.path.append(r"/usr/local/lib/python3.7/dist-packages")

import cplex
from cplex.callbacks import UserCutCallback, BranchCallback, LazyConstraintCallback, NodeCallback
